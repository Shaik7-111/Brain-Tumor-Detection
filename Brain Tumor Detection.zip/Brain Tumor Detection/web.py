import streamlit as st
from PIL import Image, ImageOps
import tensorflow as tf
import numpy as np

# Load the pre-trained model
model = tf.keras.models.load_model("keras_model.h5")

# Define the class names for brain tumor types
class_names = ['No Tumor', 'Glioma Tumor', 'Meningioma Tumor', 'Pituitary Tumor']

st.title('Brain Tumor Detection')

img_file = st.file_uploader('Upload brain MRI image', type=['png', 'jpg', 'jpeg'])

def load_img(img):
    img = Image.open(img)
    return img

if img_file is not None:
    file_details = {}
    file_details['name'] = img_file.name
    file_details['size'] = img_file.size
    file_details['type'] = img_file.type
    st.write(file_details)
    st.image(load_img(img_file), width=255)

    # Load the uploaded image
    image = load_img(img_file)

    # Preprocess the image
    size = (224, 224)
    image = ImageOps.fit(image, size, Image.Resampling.LANCZOS)
    image_array = np.asarray(image)
    normalized_image_array = (image_array.astype(np.float32) / 255.0)  # Normalize to [0,1]
    data = np.expand_dims(normalized_image_array, axis=0)

    # Make prediction
    prediction = model.predict(data)
    class_index = np.argmax(prediction)
    class_name = class_names[class_index]
    st.success(f"The MRI scan indicates: {class_name}")
